// versions would be a 1D array with either '0' or '1' as its elements.
// '0' indicates the version is bug-free and '1' indicates the version is buggy.
// (Ex - For input [0, 0, 1, 1, 1], the bug was introduced in version 2 and the function should return 1)

function lastBugFreeVersion(versions) {
  const freeVersion = versions.filter(e => e!== 1)  
  freeVersion.forEach((e,i) => {
  document.querySelector('h1 span').innerHTML = i
  document.querySelector('h2 span').innerHTML = i+1
  })
}

lastBugFreeVersion([0, 0, 1, 1, 1]);
